# Disaster Prep Quest - 3D Educational Game

## Overview
A 3D educational game built with React Three Fiber where players learn about natural disaster preparedness. Players navigate a town, talk to NPCs, and learn how to prepare for hurricanes, wildfires, and earthquakes.

## Recent Changes
- 2026-02-16: Created modular game-template/ directory - config-driven copy for building new educational games
- 2026-02-16: Added Practice Station booth with 8 if/else-if/else quiz questions, unlocked after quest completion + lesson
- 2026-02-16: Replaced earthquake "books in bag" task with "shut off gas lines with wrench"
- 2026-02-16: Added wrong-choice failure mechanic - all items from all disasters now spawn, using wrong items fails the quest
- 2026-02-16: Initial build of the game with full quest flow, NPC interactions, and dialogue system

## Project Architecture
- **Frontend**: React + TypeScript + React Three Fiber
- **Backend**: Express server (serves frontend)
- **State Management**: Zustand stores (`useGame.tsx`, `useAudio.tsx`)
- **3D Engine**: @react-three/fiber with @react-three/drei helpers

### Key Files
- `client/src/App.tsx` - Main app with start screen, Canvas, HUD, and dialogue UI
- `client/src/lib/stores/useGame.tsx` - Game state: phase, quest progress, dialogue management, random disaster selection
- `client/src/components/game/Game.tsx` - Main game component with all NPCs, dialogue logic, quest flow
- `client/src/components/game/Player.tsx` - WASD movement player character
- `client/src/components/game/NPC.tsx` - Reusable NPC component with proximity detection and E-key interaction
- `client/src/components/game/DialogueUI.tsx` - Dialogue box overlay
- `client/src/components/game/GameHUD.tsx` - Objective tracker and quest progress
- `client/src/components/game/USCStand.tsx` - USC apparel stand 3D model
- `client/src/components/game/Ground.tsx` - Grass terrain
- `client/src/components/game/Environment.tsx` - Trees, bushes, rocks, roads
- `client/src/components/game/FollowCamera.tsx` - Third-person follow camera
- `client/src/components/game/Lights.tsx` - Scene lighting
- `client/src/components/game/Sky.tsx` - Sky color and fog

### Key Files (continued)
- `client/src/components/game/WorldItem.tsx` - Pickupable items with unique IDs, consumed tracking
- `client/src/components/game/InteractionTarget.tsx` - Use-item-at-location targets with correct/wrong item handling
- `client/src/components/game/House.tsx` - House with interior, exports HOUSE_POS constant
- `client/src/components/game/PracticeBooth.tsx` - Interactive booth for programming practice quiz
- `client/src/components/game/PracticeQuizUI.tsx` - 8 multiple-choice questions on if/else-if/else branching

### Game Flow
1. Start screen -> click "Start Game"
2. Player talks to Dan at USC stand -> Dan explains disaster prep instructions for 3 types
3. Player finds Bob -> Bob reveals which random disaster is coming
4. Player reports back to Dan -> Dan gives specific prep instructions
5. ALL items from ALL disasters spawn around the house
6. Player must pick correct items and use them at correct targets
7. Using wrong items or doing wrong disaster prep = quest failure
8. Completing all correct tasks = quest success
9. Programming lesson screen shows if/else-if/else analogy to disaster prep choices
10. "Continue Playing" button unlocks the Practice Station booth
11. Player visits booth and takes 8-question quiz on branching statements (10 pts each)

### NPCs
- **Dan** (USC stand) - Quest giver, disaster prep instructions
- **Bob** (east side) - Reveals which disaster is coming (random)
- **Sara** - Hints and flavor dialogue
- **Mike** - Hints and flavor dialogue
- **Lisa** - General disaster prep education
